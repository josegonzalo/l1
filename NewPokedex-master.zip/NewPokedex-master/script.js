// DECLARACION DE MODULE POKEDEX
var  Pokemon= angular.module("Pokemon",[]);
 //Creacion del controlador
 Pokemon.controller("ListadoPokemon",function($scope,$http){
 	$scope.j1 = ""
 	$scope.j2 = ""

 	$scope.url="https://pokeapi.co/api/v2/pokemon/50"
 	// para llamar las Api
 	$http({
 		method:"POST",

 		url: $scope.url

 	}).then(function successCALLback(datos){
 		$scope.j1 = datos.data.name
 		$scope.j2 = datos.data.sprites.front_default
 		console.log(datos)
 	})
 });